config = {
    'ssl_loss_weight': 0.1,
    'probability_threshold': 0.5,
    'pseudo_graph_weight': 0,
    'k': 100,
    "pseudo_labels_update_epoch": 1,
    "pred_weight": 'sampling_rate',

}