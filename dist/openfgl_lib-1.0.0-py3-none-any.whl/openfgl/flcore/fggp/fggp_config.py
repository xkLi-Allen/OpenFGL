config = {
    "params_weight": 'samples_num',
    "neibor_num": 3,
    "N_CLASS":10
}