

config = {
    "prop_steps": 3,
    "num_rounds_vanilla": 50,
    "r": 0.5,
    "adafgl_lr": 1e-2,
    "adafgl_weight_decay": 5e-4,
}