config = {
    'eps1': 0.05,
    'eps2': 0.1,
    'seq_length': 5,
    'standardize': False
}
