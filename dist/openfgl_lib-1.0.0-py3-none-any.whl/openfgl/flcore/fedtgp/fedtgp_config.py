config = {
    "fedtgp_lambda": 1
}