config = {
    "hidden_portion": 0.5,
    "latent_dim": 128,
    "max_pred": 5,
    "gen_rounds":10,
    "num_missing_trade_off": 1,
    "missing_feat_trade_off": 1,
    "cls_trade_off": 1
}