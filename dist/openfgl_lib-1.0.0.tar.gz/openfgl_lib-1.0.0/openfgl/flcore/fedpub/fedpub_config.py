config = {
    'agg_norm': 'exp',
    'norm_scale': 10,
    'laye_mask_one': True,
    'clsf_mask_one': True,
    'l1': 1e-3,
    'loc_l2': 1e-3,
    'n_proxy': 5
}

