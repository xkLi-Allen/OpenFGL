config = {
    "moon_mu": 1,
    "temperature": 0.5
}