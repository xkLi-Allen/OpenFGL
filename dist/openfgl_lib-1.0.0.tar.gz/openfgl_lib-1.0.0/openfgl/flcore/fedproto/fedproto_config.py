config = {
    "fedproto_lambda": 1
}