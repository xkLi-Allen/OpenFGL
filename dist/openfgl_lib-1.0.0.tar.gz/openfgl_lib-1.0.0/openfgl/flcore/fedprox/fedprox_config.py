config = {
    "fedprox_mu": 1e-3
}